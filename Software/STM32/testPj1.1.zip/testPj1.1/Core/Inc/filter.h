/*
 * filter.h
 *
 *  Created on: Mar 14, 2024
 *      Author: knn
 */

#ifndef INC_FILTER_H_
#define INC_FILTER_H_

#include "sgtl5000.h"

extern ADC_HandleTypeDef hadc1;

typedef struct param_sgtl_struct
{
    int volume;
    int bandmod;
    int band0_freq;
    int band0_gain;
    int band1_freq;
    int band1_gain;
    int band2_freq;
    int band2_gain;
    int band3_freq;
    int band3_gain;
} param_sgtl_t;

sgtl5000_registers_t MSB_coef[] =
{
		SGTL5000_DAP_COEF_WR_B0_MSB,
		SGTL5000_DAP_COEF_WR_B1_MSB,
		SGTL5000_DAP_COEF_WR_B2_MSB,
		SGTL5000_DAP_COEF_WR_A1_MSB,
		SGTL5000_DAP_COEF_WR_A2_MSB
};

sgtl5000_registers_t LSB_coef[] = {
		SGTL5000_DAP_COEF_WR_B0_LSB,
		SGTL5000_DAP_COEF_WR_B1_LSB,
		SGTL5000_DAP_COEF_WR_B2_LSB,
		SGTL5000_DAP_COEF_WR_A1_LSB,
		SGTL5000_DAP_COEF_WR_A2_LSB
};

void init_valeur_default(param_sgtl_t* param_son);
void init_filter(ADC_HandleTypeDef * hadc1,uint16_t* value_pot);
void modif_valeur(param_sgtl_t *,int signalA, int signalB);
void modif_gain(param_sgtl_t *,int signalA, int singalB);
void ChangementEtat(param_sgtl_t*,h_sgtl5000_t *);
void calc_eq_coefs(int freq,float gain_dB,int * coefs);
void volume(param_sgtl_t * var,h_sgtl5000_t * sgtl,uint16_t  in12bits);
void set_filter(h_sgtl5000_t * sgtl,int freq, float gain_dB);
void set_coef(h_sgtl5000_t * sgtl,int coef,int i);


#endif /* INC_FILTER_H_ */

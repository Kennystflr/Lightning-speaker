
/*
 * mywork.c
 *
 *  Created on: Mar 14, 2024
 *      Author: knn
 */
#ifndef SAMPLE_RATE
#define SAMPLE_RATE 48000
#endif
#define GAIN_INCREMENT 1


#include <stdio.h>
#include <math.h>
#include "main.h"
#include <filter.h>


extern ADC_HandleTypeDef hadc1;

sgtl5000_registers_t MSB_coef[] =
{
		SGTL5000_DAP_COEF_WR_B0_MSB,
		SGTL5000_DAP_COEF_WR_B1_MSB,
		SGTL5000_DAP_COEF_WR_B2_MSB,
		SGTL5000_DAP_COEF_WR_A1_MSB,
		SGTL5000_DAP_COEF_WR_A2_MSB
};

sgtl5000_registers_t LSB_coef[] = {
		SGTL5000_DAP_COEF_WR_B0_LSB,
		SGTL5000_DAP_COEF_WR_B1_LSB,
		SGTL5000_DAP_COEF_WR_B2_LSB,
		SGTL5000_DAP_COEF_WR_A1_LSB,
		SGTL5000_DAP_COEF_WR_A2_LSB};


void calc_eq_coefs(int freq, float gain_dB, int coef[4]){

	float Q = 1.5 ;
	float omega = (float) 2*M_PI*freq/SAMPLE_RATE;
	float alpha =(float) sin(omega)/(2*Q);
	float A = pow(10,gain_dB/40);

	float b_0 = 1 + alpha * A;
	float b_1 = -2 * cos(omega);
	float b_2 = 1 - alpha * A;
	float a_0 = 1 + (alpha / A);
	float a_1 = -2 * cos(omega);
	float a_2 = 1 - (alpha / A);


	coef[0] = (int) (b_0/a_0 + 0.499);
	coef[1] = (int) (b_1/a_0 + 0.499);
	coef[2] = (int) (b_2/a_0  + 0.499);
	coef[3] = (int) (a_1/a_0  + 0.499);
	coef[4] = (int) (a_2/a_0  + 0.499);

}


void volume(param_sgtl_t * param_son,h_sgtl5000_t  * sgtl){
	uint16_t value_pot;
	HAL_ADC_Start_DMA(&hadc1,(uint32_t *)&value_pot,1);
	HAL_Delay(0);
	HAL_ADC_Stop_DMA(&hadc1);
	modif_volume(param_son,value_pot);
	sgtl5000_i2c_write_register(sgtl,SGTL5000_DAP_MAIN_CHAN,(uint32_t) param_son->volume);
}

void set_filter(h_sgtl5000_t * sgtl,int freq, float gain_dB){
	int coefs[4];
	calc_eq_coefs(freq,gain_dB,coefs);
	for (int i=0;i<5;i++){
		set_coef(sgtl,coefs[i],i);
	}
}

void set_coef(h_sgtl5000_t * sgtl, int coef, int i){
	sgtl5000_i2c_write_register(sgtl,LSB_coef[i], coef & 0xF);//Recupération des 4 derniers bits sur 20 du coefficient
	sgtl5000_i2c_write_register(sgtl,MSB_coef[i], ((coef &0xFFFF0)>>2));//Recupération des 16 premiers bits sur 20 du coefficient
}

void init_valeur_default(param_sgtl_t* param_son){
	param_son->band0_freq=450;
	param_son->band1_freq=1900;
	param_son->band2_freq=5500;
	param_son->band3_freq=12000;
	param_son->band0_gain=0;
	param_son->band1_gain=0;
	param_son->band2_gain=0;
	param_son->band3_gain=0;
	param_son->volume=0;
	param_son->bandmod = 0;
}

void modif_freq(param_sgtl_t * param_son, int signalA, int signalB){

	int difffrequence=0;

	switch(param_son->bandmod){

	case 0 :
		difffrequence=700/50;
		if(signalA==1){ //on suppose que si B est en retard, on tourne ds le sens horaire
			if(signalB==0){
				param_son->band0_freq += difffrequence;
			}
			else {
				param_son->band0_freq -= difffrequence;
			}
		}
		break;

	case 1 :
		difffrequence=2200/50;
		if(signalA==1){ //on suppose que si B est en retard, on tourne ds le sens horaire
			if(signalB==0){
				param_son->band1_freq += difffrequence;
			}
			else {
				param_son->band1_freq -= difffrequence;
			}
		}
		break;

	case 2 :
		difffrequence=5000/50;
		if(signalA==1){ //on suppose que si B est en retard, on tourne ds le sens horaire
			if(signalB==0){
				param_son->band2_freq += difffrequence;
			}
			else {
				param_son->band2_freq -= difffrequence;
			}
		}
		break;

	case 3 :
		difffrequence=8000/50;
		if(signalA==1){ //on suppose que si B est en retard, on tourne ds le sens horaire
			if(signalB==0){
				param_son->band3_freq += difffrequence;
			}
			else {
				param_son->band3_freq -= difffrequence;
			}
		}
		break;
	}
}

void modif_gain(param_sgtl_t * param_son, int signalA, int signalB){

	switch(param_son->bandmod){

	case 0 :
		if(signalA==1){ //on suppose que si B est en retard, on tourne ds le sens horaire
			if(signalB==0){
				param_son->band0_gain += GAIN_INCREMENT;
			}
			else {
				param_son->band0_gain -= GAIN_INCREMENT;
			}
		}
		break;

	case 1 :
		if(signalA==1){ //on suppose que si B est en retard, on tourne ds le sens horaire
			if(signalB==0){
				param_son->band1_gain += GAIN_INCREMENT;
			}
			else {
				param_son->band1_gain -= GAIN_INCREMENT;
			}
		}
		break;

	case 2 :
		if(signalA==1){ //on suppose que si B est en retard, on tourne ds le sens horaire
			if(signalB==0){
				param_son->band2_gain += GAIN_INCREMENT;
			}
			else {
				param_son->band2_gain -= GAIN_INCREMENT;
			}
		}
		break;

	case 3 :
		if(signalA==1){ //on suppose que si B est en retard, on tourne ds le sens horaire
			if(signalB==0){
				param_son->band3_gain += GAIN_INCREMENT;
			}
			else {
				param_son->band3_gain -= GAIN_INCREMENT;
			}
		}
		break;
	}
}

void modif_volume(param_sgtl_t * param_son, int in12bits){
	int nombrevaleurs=(int)(0.6*4096/128);
	for(int multiple=0; multiple<128; multiple++){
		if(in12bits>nombrevaleurs*multiple-1 && in12bits < nombrevaleurs * multiple + nombrevaleurs){
			param_son->volume=multiple;
		}
	}
}

void ChangementEtat(param_sgtl_t * param_son,h_sgtl5000_t * sgtl){

	if(HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET) {
		// Le bouton est enfoncé
		switch(param_son->bandmod)
		{
		case 0:
			while(HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET){}
			sgtl5000_i2c_write_register(sgtl,SGTL5000_DAP_FILTER_COEF_ACCESS,(uint32_t) 0x1 );
			param_son->bandmod =1;
		case 1:
			while(HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET){}
			sgtl5000_i2c_write_register(sgtl,SGTL5000_DAP_FILTER_COEF_ACCESS,(uint32_t) 0x2 );
			param_son->bandmod = 2;
		case 2:
			while(HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET){}
			sgtl5000_i2c_write_register(sgtl,SGTL5000_DAP_FILTER_COEF_ACCESS,(uint32_t) 0x3 );
			param_son->bandmod = 3;
		case 3:
			while(HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == GPIO_PIN_RESET){}
			sgtl5000_i2c_write_register(sgtl,SGTL5000_DAP_FILTER_COEF_ACCESS,(uint32_t) 0x0 );
			param_son->bandmod = 0;
		}
	} else {
		// Le bouton n'est pas enfoncé
	}
}

void set_param(param_sgtl_t  * param_son, h_sgtl5000_t * sgtl){

}


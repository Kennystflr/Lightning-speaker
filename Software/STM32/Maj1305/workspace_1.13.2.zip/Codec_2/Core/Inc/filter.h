/*
 * mywork.h
 *
 *  Created on: Mar 14, 2024
 *      Author: knn
 */

#ifndef INC_FILTER_H_
#define INC_FILTER_H_

#include "sgtl5000.h"


typedef struct param_sgtl_struct
{
    int volume;
    int bandmod;
    int band0_freq;
    int band0_gain;
    int band1_freq;
    int band1_gain;
    int band2_freq;
    int band2_gain;
    int band3_freq;
    int band3_gain;
} param_sgtl_t;

void ini_valeur_default(void);
void modif_volume(param_sgtl_t *,int in12bits);
void modif_valeur(param_sgtl_t *,int signalA, int signalB);
void modif_gain(param_sgtl_t *,int signalA, int singalB);
void ChangementEtat(param_sgtl_t*,h_sgtl5000_t *);
void calc_eq_coefs(int freq,float gain_dB,int * coefs);
void volume(param_sgtl_t * var,h_sgtl5000_t * sgtl);
void set_filter(h_sgtl5000_t * sgtl,int freq, float gain_dB);
void set_coef(h_sgtl5000_t * sgtl,param_sgtl_t * param_son,int coef,int i);
void set_param(param_sgtl_t  * param_son, h_sgtl5000_t * sgtl);


#endif /* INC_FILTER_H_ */
